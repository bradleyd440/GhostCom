# GhostCom

**GhostCom** is a privacy-first, secure messaging app with built-in cryptocurrency support. 
It features **end-to-end encryption** using the Signal Protocol and provides **non-custodial wallet** functionality for Ethereum-based tokens.

### Features:
- End-to-end encrypted messaging
- Biometric authentication (FaceID/TouchID)
- Ethereum wallet support
- Privacy-focused architecture

### Getting Started:
Clone the repo and run the app on iOS/Android using Expo.

1. Clone this repo
2. Install dependencies: `npm install`
3. Start the app: `expo start`
